package com.taskbridge;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import com.taskbridge.common.*;
import com.taskbridge.notifications.dto.*;
import com.taskbridge.notifications.model.*;
import com.taskbridge.notifications.repository.*;
import com.taskbridge.notifications.service.*;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.*;
class NotificationAndAuditServiceTest {
 private final UUID org=UUID.randomUUID(), user=UUID.randomUUID(), project=UUID.randomUUID();
 private final TenantContext tenant=new TenantContext(user,org,"127.0.0.1");
 @Test void dispatchesEqualNotificationToAllTeamMembers(){
  NotificationRepository repo=mock(NotificationRepository.class); when(repo.save(any())).thenAnswer(i->i.getArgument(0));
  var service=new NotificationService(repo); Set<UUID> members=Set.of(UUID.randomUUID(),UUID.randomUUID(),UUID.randomUUID());
  var result=service.dispatch(members,project,EventType.MILESTONE_UPDATED,"changed",org);
  assertEquals(members.size(),result.size()); assertEquals(members,result.stream().map(NotificationResponse::recipientUserId).collect(java.util.stream.Collectors.toSet())); verify(repo,times(3)).save(any());
 }
 @Test void createsAuditEntryWhenMilestoneUpdated(){
  AuditEntryRepository repo=mock(AuditEntryRepository.class); when(repo.save(any())).thenAnswer(i->i.getArgument(0)); var service=new AuditService(repo);
  var out=service.record(new CreateAuditRequest(EventType.MILESTONE_UPDATED,"PROJECT_MILESTONE",project,project,"before","after"),tenant);
  assertEquals(EventType.MILESTONE_UPDATED,out.eventType()); assertEquals("before",out.previousState()); assertEquals("after",out.newState()); assertEquals(org,out.organisationId()); verify(repo).save(any(AuditEntry.class));
 }
 @Test void auditEntryCannotBeDeletedOrOverwritten(){
  var service=new AuditService(mock(AuditEntryRepository.class));
  assertThrows(ConflictException.class,()->service.delete(UUID.randomUUID()));
  assertThrows(ConflictException.class,()->service.overwrite(UUID.randomUUID(),new CreateAuditRequest(EventType.MILESTONE_UPDATED,"PROJECT_MILESTONE",project,project,"a","b")));
 }
 @Test void auditHistoryFiltersByDateRange(){
  AuditEntryRepository repo=mock(AuditEntryRepository.class); Instant from=Instant.parse("2026-01-01T00:00:00Z"),to=Instant.parse("2026-01-31T23:59:59Z");
  when(repo.search(project,org,from,to,null)).thenReturn(List.of()); var service=new AuditService(repo);
  assertTrue(service.history(project,from,to,null,tenant).isEmpty()); verify(repo).search(project,org,from,to,null);
 }
 @Test void auditHistoryFiltersByEventType(){
  AuditEntryRepository repo=mock(AuditEntryRepository.class); when(repo.search(project,org,null,null,EventType.MILESTONE_REOPENED)).thenReturn(List.of()); var service=new AuditService(repo);
  service.history(project,null,null,EventType.MILESTONE_REOPENED,tenant); verify(repo).search(project,org,null,null,EventType.MILESTONE_REOPENED);
 }
 @Test void unauthorisedUserCannotAccessAnotherOrganisationsAuditLog(){
  AuditEntryRepository repo=mock(AuditEntryRepository.class); var service=new AuditService(repo); UUID otherOrg=UUID.randomUUID(); TenantContext attacker=new TenantContext(user,otherOrg,"127.0.0.2");
  when(repo.search(project,otherOrg,null,null,null)).thenReturn(List.of()); service.history(project,null,null,null,attacker);
  verify(repo).search(project,otherOrg,null,null,null); verify(repo,never()).search(eq(project),eq(org),any(),any(),any());
 }
}