package com.taskbridge.notifications.service;
import com.taskbridge.common.*;
import com.taskbridge.notifications.dto.NotificationResponse;
import com.taskbridge.notifications.model.*;
import com.taskbridge.notifications.repository.NotificationRepository;
import java.time.Instant;
import java.util.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class NotificationService {
 private final NotificationRepository repository;
 public NotificationService(NotificationRepository repository){ this.repository=repository; }
 /** Creates one equally scoped notification for every unique team member. */
 @Transactional public List<NotificationResponse> dispatch(Set<UUID> recipients,UUID projectId,EventType eventType,String message,UUID organisationId){
  return recipients.stream().map(id->new Notification(id,organisationId,eventType,projectId,message,Instant.now())).map(repository::save).map(this::toResponse).toList();
 }
 /** Returns unread notifications only for the authenticated user and tenant. */
 @Transactional(readOnly=true) public List<NotificationResponse> unread(UUID requestedUserId,TenantContext tenant){
  if(!requestedUserId.equals(tenant.userId())) throw new ForbiddenException("Users may only read their own notifications");
  return repository.findAllByRecipientUserIdAndOrganisationIdAndReadFalseOrderByCreatedAtDesc(requestedUserId,tenant.organisationId()).stream().map(this::toResponse).toList();
 }
 /** Marks a tenant-owned notification as read. */
 @Transactional public NotificationResponse markRead(UUID id,TenantContext tenant){
  Notification n=repository.findByIdAndOrganisationId(id,tenant.organisationId()).orElseThrow(()->new NotFoundException("Notification not found"));
  if(!n.getRecipientUserId().equals(tenant.userId())) throw new ForbiddenException("Notification belongs to another user");
  n.markRead(); return toResponse(n);
 }
 private NotificationResponse toResponse(Notification n){ return new NotificationResponse(n.getId(),n.getRecipientUserId(),n.getEventType(),n.getProjectId(),n.getMessage(),n.isRead(),n.getCreatedAt()); }
}