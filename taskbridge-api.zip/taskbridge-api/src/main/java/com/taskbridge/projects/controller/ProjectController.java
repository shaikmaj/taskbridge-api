package com.taskbridge.projects.controller;
import com.taskbridge.common.*;
import com.taskbridge.projects.dto.*;
import com.taskbridge.projects.service.ProjectService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import java.util.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/projects")
public class ProjectController {
 private final ProjectService service; private final TenantContextResolver resolver;
 public ProjectController(ProjectService service,TenantContextResolver resolver){this.service=service;this.resolver=resolver;}
 @PostMapping ResponseEntity<ProjectResponse> create(@Valid @RequestBody CreateProjectRequest body,HttpServletRequest req){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(body,resolver.resolve(req)));}
 @GetMapping("/{id}") ProjectResponse get(@PathVariable UUID id,HttpServletRequest req){return service.get(id,resolver.resolve(req));}
 @GetMapping List<ProjectResponse> byTeam(@RequestParam UUID teamMemberId,HttpServletRequest req){return service.getByTeam(teamMemberId,resolver.resolve(req));}
 @PatchMapping("/{id}/status") ProjectResponse update(@PathVariable UUID id,@Valid @RequestBody UpdateProjectStatusRequest body,HttpServletRequest req){return service.updateStatus(id,body,resolver.resolve(req));}
 @DeleteMapping("/{id}") ResponseEntity<Void> delete(@PathVariable UUID id,HttpServletRequest req){service.delete(id,resolver.resolve(req));return ResponseEntity.noContent().build();}
}