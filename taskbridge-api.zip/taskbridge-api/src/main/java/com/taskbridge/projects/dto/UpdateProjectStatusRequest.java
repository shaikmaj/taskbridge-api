package com.taskbridge.projects.dto;
import com.taskbridge.projects.model.ProjectStatus;
import jakarta.validation.constraints.NotNull;
public record UpdateProjectStatusRequest(@NotNull ProjectStatus status) {}