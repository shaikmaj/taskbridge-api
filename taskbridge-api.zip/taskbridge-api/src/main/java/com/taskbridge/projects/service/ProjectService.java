package com.taskbridge.projects.service;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.taskbridge.common.*;
import com.taskbridge.notifications.dto.CreateAuditRequest;
import com.taskbridge.notifications.model.EventType;
import com.taskbridge.notifications.service.*;
import com.taskbridge.projects.dto.*;
import com.taskbridge.projects.model.*;
import com.taskbridge.projects.repository.ProjectRepository;
import java.util.*;
import org.slf4j.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
public class ProjectService {
 private static final Logger log=LoggerFactory.getLogger(ProjectService.class);
 private final ProjectRepository repository; private final AuditService auditService; private final NotificationService notificationService; private final ObjectMapper objectMapper;
 public ProjectService(ProjectRepository repository,AuditService auditService,NotificationService notificationService,ObjectMapper objectMapper){ this.repository=repository;this.auditService=auditService;this.notificationService=notificationService;this.objectMapper=objectMapper; }
 /** Creates a tenant-owned project and emits audit and notification records. */
 @Transactional public ProjectResponse create(CreateProjectRequest request,TenantContext tenant){
  Project p=new Project(); p.setOrganisationId(tenant.organisationId());p.setName(request.name().trim());p.setStatus(ProjectStatus.OPEN);p.setTeamMemberIds(new HashSet<>(request.teamMemberIds()));
  p=repository.save(p); emit(p,null,EventType.MILESTONE_CREATED,tenant); log.info("Project created projectId={}",p.getId()); return toResponse(p);
 }
 /** Updates status only after loading the project through its tenant-scoped key. */
 @Transactional public ProjectResponse updateStatus(UUID id,UpdateProjectStatusRequest request,TenantContext tenant){
  Project p=getEntity(id,tenant.organisationId()); String previous=json(p); ProjectStatus old=p.getStatus(); p.setStatus(request.status());
  EventType type=request.status()==ProjectStatus.CLOSED?EventType.MILESTONE_CLOSED:(old==ProjectStatus.CLOSED?EventType.MILESTONE_REOPENED:EventType.MILESTONE_UPDATED);
  emit(p,previous,type,tenant); log.info("Project status updated projectId={} status={}",id,request.status()); return toResponse(p);
 }
 /** Gets a project only when it belongs to the current tenant. */
 @Transactional(readOnly=true) public ProjectResponse get(UUID id,TenantContext tenant){ return toResponse(getEntity(id,tenant.organisationId())); }
 /** Gets projects for a team member within the current tenant. */
 @Transactional(readOnly=true) public List<ProjectResponse> getByTeam(UUID memberId,TenantContext tenant){ return repository.findAllByOrganisationIdAndTeamMemberIdsContaining(tenant.organisationId(),memberId).stream().map(this::toResponse).toList(); }
 /** Deletes a tenant-owned project after appending its final audit event. */
 @Transactional public void delete(UUID id,TenantContext tenant){ Project p=getEntity(id,tenant.organisationId()); String previous=json(p); emit(p,previous,EventType.MILESTONE_DELETED,tenant,"{}"); repository.delete(p); }
 private Project getEntity(UUID id,UUID org){ return repository.findByIdAndOrganisationId(id,org).orElseThrow(()->new NotFoundException("Project not found")); }
 private void emit(Project p,String previous,EventType type,TenantContext tenant){ emit(p,previous,type,tenant,json(p)); }
 private void emit(Project p,String previous,EventType type,TenantContext tenant,String next){
  auditService.record(new CreateAuditRequest(type,"PROJECT_MILESTONE",p.getId(),p.getId(),previous,next),tenant);
  notificationService.dispatch(p.getTeamMemberIds(),p.getId(),type,"Project '"+p.getName()+"' changed: "+type,p.getOrganisationId());
 }
 private String json(Project p){ try{return objectMapper.writeValueAsString(toResponse(p));}catch(JsonProcessingException e){throw new IllegalStateException("Could not serialise project snapshot",e);} }
 private ProjectResponse toResponse(Project p){ return new ProjectResponse(p.getId(),p.getOrganisationId(),p.getName(),p.getStatus(),Set.copyOf(p.getTeamMemberIds()),p.getCreatedAt(),p.getUpdatedAt()); }
}