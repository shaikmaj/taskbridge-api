package com.taskbridge.projects.dto;
import com.taskbridge.projects.model.ProjectStatus;
import java.time.Instant;
import java.util.Set;
import java.util.UUID;
public record ProjectResponse(UUID id,UUID organisationId,String name,ProjectStatus status,Set<UUID> teamMemberIds,Instant createdAt,Instant updatedAt) {}