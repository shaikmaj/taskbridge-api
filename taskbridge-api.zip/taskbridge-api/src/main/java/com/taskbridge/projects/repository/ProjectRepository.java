package com.taskbridge.projects.repository;
import com.taskbridge.projects.model.Project;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProjectRepository extends JpaRepository<Project,UUID> {
 Optional<Project> findByIdAndOrganisationId(UUID id,UUID organisationId);
 List<Project> findAllByOrganisationIdAndTeamMemberIdsContaining(UUID organisationId,UUID teamMemberId);
}