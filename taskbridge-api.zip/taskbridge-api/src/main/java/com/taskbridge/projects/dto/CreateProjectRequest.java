package com.taskbridge.projects.dto;
import jakarta.validation.constraints.*;
import java.util.Set;
import java.util.UUID;
public record CreateProjectRequest(@NotBlank @Size(max=120) String name, @NotEmpty Set<@NotNull UUID> teamMemberIds) {}